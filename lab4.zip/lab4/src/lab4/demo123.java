package lab4;
import java.util.*; 
class Test { 
public static void main (String[] args) { 
Set hashSet = new HashSet(); 
hashSet.add(1); 
hashSet.add(null); 
hashSet.add(null); 
hashSet.add("1");
System.out.println(hashSet);
 } 
}
